# Signature Verification

If `manifest.sig` and `signing_public_key.pem` are present, verify Ed25519 signature using your preferred toolchain.
